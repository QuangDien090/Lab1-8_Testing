package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object User
     
    /**
     * <p></p>
     */
    public static Object Pass
     
    /**
     * <p></p>
     */
    public static Object UserWrong
     
    /**
     * <p></p>
     */
    public static Object PassWrong
     
    /**
     * <p></p>
     */
    public static Object UserEmpty
     
    /**
     * <p></p>
     */
    public static Object PassEmpty
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            url = selectedVariables['url']
            User = selectedVariables['User']
            Pass = selectedVariables['Pass']
            UserWrong = selectedVariables['UserWrong']
            PassWrong = selectedVariables['PassWrong']
            UserEmpty = selectedVariables['UserEmpty']
            PassEmpty = selectedVariables['PassEmpty']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
